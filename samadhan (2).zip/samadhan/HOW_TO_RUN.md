# Samadhan — How to run & what keys to add

This app **works immediately with no keys** (demo mode: built-in AI + seeded Mumbai data).
Add a Gemini key only when you want the real AI. Follow the steps below.

---

## 0. Prerequisite (one-time)
Install **Node.js 20 or newer** → https://nodejs.org (the "LTS" download).
Check it's installed:
```bash
node -v      # should print v20.x or higher
```

---

## 1. Unzip
Unzip `samadhan.zip`. You'll get a `samadhan/` folder with `index.html`, `server.js`, etc.
Open a terminal **inside that folder**:
```bash
cd samadhan
```

---

## 2. Install
```bash
npm install
```

---

## 3. Run
```bash
npm start
```
Open the printed link → **http://localhost:8080**

That's it — the full app runs in **demo mode** (no keys needed). To switch on real AI, do step 4.

---

## 4. Add your keys (optional — for real AI / cloud sync)

### A) Gemini key — REQUIRED for real AI (free, no credit card)
This one key powers the AI **and** the in-app translation.

1. Go to **https://aistudio.google.com/app/apikey** → sign in → **Create API key** → copy it.
2. In the `samadhan` folder, make your env file:
   ```bash
   cp .env.example .env
   ```
3. Open `.env` and paste your key:
   ```
   GEMINI_API_KEY=AIza...your_key_here...
   ```
4. Restart: stop the server (Ctrl+C) and run `npm start` again.

The key lives **only** in `.env` (server-side). It is never sent to the browser.

### B) Firebase — OPTIONAL (only for cloud sync across devices)
Without this, the app stores data on the device. To enable cloud sync:

1. Go to **https://console.firebase.google.com** → create a project → add a **Web app** → copy the config object.
2. Open `index.html`, find the `CONFIG` block near the top of the `<script>`, and replace the
   `FIREBASE` placeholder values (`YOUR_...`) with your real config:
   ```js
   FIREBASE: {
     apiKey:            "AIza...",
     authDomain:        "your-project.firebaseapp.com",
     projectId:         "your-project-id",
     storageBucket:     "your-project.appspot.com",
     messagingSenderId: "1234567890",
     appId:             "1:1234:web:abcd"
   },
   ```
   (Free **Spark** plan, no credit card needed.)

### What goes where — quick table
| Key | Where it goes | Required? | Get it from |
|---|---|---|---|
| `GEMINI_API_KEY` | `.env` | For real AI (else demo) | https://aistudio.google.com/app/apikey |
| Firebase config | `CONFIG.FIREBASE` in `index.html` | Optional (cloud sync) | https://console.firebase.google.com |
| Maps / Translation / Voice / Photos | — | **Nothing to add** | keyless / built-in |

---

## 5. Deploy to Google Cloud Run (the hackathon's required host)
1. Install the gcloud CLI and run `gcloud auth login` (one-time).
2. From inside the `samadhan` folder:
   ```bash
   gcloud run deploy samadhan --source . --region asia-south1 \
     --allow-unauthenticated --set-env-vars GEMINI_API_KEY=your_key_here
   ```
3. Cloud Run prints a public **https URL** — that's your submission link.

You do **not** upload `.env` to Cloud Run; the key is passed with `--set-env-vars`.
A `Dockerfile` is included, but Cloud Run can also build straight from source.

---

## Troubleshooting
- **"node: command not found"** → install Node.js (step 0).
- **Port 8080 busy** → run `PORT=3000 npm start` and open http://localhost:3000.
- **Banner says "Demo mode"** → no Gemini key found; that's expected until you add one in `.env`.
- **Translation stays English for a moment** → first switch to a new language fetches + caches; it's instant afterward.
