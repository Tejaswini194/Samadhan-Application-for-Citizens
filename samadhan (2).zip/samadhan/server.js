/**
 * Samadhan — minimal server
 * - Serves the static app (index.html)
 * - Proxies Gemini calls at /api/gemini so the API key NEVER touches the browser
 *
 * Required env var:  GEMINI_API_KEY   (set in .env locally, or in Cloud Run)
 * Optional env var:  GEMINI_MODEL     (default: gemini-2.5-flash)
 */
const express = require('express');
const path = require('path');

const app = express();
app.use(express.json({ limit: '12mb' })); // images arrive as base64
app.use(express.static(path.join(__dirname)));

const KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const API = m => `https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent`;

// ---- helper: call Gemini ----
async function callGemini(body) {
  const res = await fetch(API(MODEL) + `?key=${KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error('Gemini ' + res.status + ' ' + (await res.text()));
  const data = await res.json();
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
}

app.post('/api/gemini', async (req, res) => {
  // If no key configured, tell the client to use demo mode.
  if (!KEY) return res.status(503).json({ error: 'no_key' });

  try {
    const { task, image, message, history, texts, langName } = req.body;

    // ---------- TRANSLATION (Google Gemini) ----------
    if (task === 'translate') {
      if (!Array.isArray(texts) || !texts.length) return res.json({ translations: [] });
      const prompt =
`Translate each string in this JSON array into ${langName || 'the target language'}.
Rules: keep the SAME order and the SAME number of items; translate naturally and concisely;
do NOT translate brand names, IDs, or numbers; return ONLY a JSON array of strings, no markdown.

${JSON.stringify(texts)}`;
      const text = await callGemini({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.1, responseMimeType: 'application/json' }
      });
      let arr;
      try { arr = JSON.parse(text); } catch { arr = null; }
      if (!Array.isArray(arr) || arr.length !== texts.length) return res.json({ translations: null });
      return res.json({ translations: arr });
    }

    // ---------- IMAGE ANALYSIS ----------
    if (task === 'analyze') {
      const parts = [{
        text:
`You are a civic issue triage agent for an Indian municipality. Analyse the photo and respond with STRICT JSON only, no markdown:
{"category": one of ["pothole","water","light","waste","tree","other"],
 "severity": one of ["low","med","high"],
 "title": short factual title (max 9 words),
 "desc": 1-2 sentence description a citizen can submit}
Base severity on safety risk. If no clear civic issue, use "other".`
      }];
      if (image) {
        const [meta, b64] = image.split(',');
        const mime = (meta.match(/data:(.*?);/) || [])[1] || 'image/jpeg';
        parts.push({ inline_data: { mime_type: mime, data: b64 } });
      }
      const text = await callGemini({
        contents: [{ role: 'user', parts }],
        generationConfig: { temperature: 0.2, responseMimeType: 'application/json' }
      });
      let out;
      try { out = JSON.parse(text); }
      catch { return res.json({}); } // client falls back to demo
      return res.json(out);
    }

    // ---------- CHATBOT ----------
    if (task === 'chat') {
      const sys =
`You are "Saathi", a friendly civic guide inside the Samadhan app (a hyperlocal issue-reporting platform).
Help citizens report issues (pothole, water leak, streetlight, garbage), track status, verify reports, and understand civic points/levels (Citizen → Guardian → Community Hero → Civic Champion). Reply in the user's language (English/Hindi/Marathi). Keep replies under 70 words, warm and practical.`;
      const contents = [{ role: 'user', parts: [{ text: sys }] }, { role: 'model', parts: [{ text: 'Understood — I am Saathi.' }] }];
      (history || []).forEach(h => contents.push({ role: h.who === 'user' ? 'user' : 'model', parts: [{ text: h.text }] }));
      contents.push({ role: 'user', parts: [{ text: message }] });
      const reply = await callGemini({ contents, generationConfig: { temperature: 0.6 } });
      return res.json({ reply: reply.trim() });
    }

    res.status(400).json({ error: 'unknown_task' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'gemini_failed' }); // client falls back to demo
  }
});

// SPA fallback
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'index.html')));

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Samadhan running on http://localhost:${PORT}  (Gemini key: ${KEY ? 'set' : 'MISSING → demo mode'})`));
