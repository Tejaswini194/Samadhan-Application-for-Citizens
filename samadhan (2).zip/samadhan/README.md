# Samadhan — Community Hero 🛡️

> **An autonomous AI civic agent.** A citizen snaps one photo; the agent categorises the issue, drafts a formal complaint, files it to the right municipal department, tracks the SLA, escalates if ignored, and verifies the fix — while the community earns civic points for participating.

Built for **Problem Statement 2 — Community Hero (Hyperlocal Problem Solver)**.

## Quick start (and where keys go)

```bash
npm install
cp .env.example .env        # then paste your Gemini key into .env
npm start                   # → http://localhost:8080
```
It runs fully in **demo mode with no keys** (smart on-device AI, seeded Mumbai data). Add keys to go live.

### The Google-native stack
| Layer | Google service | Needs a card? | Where the key goes |
|---|---|---|---|
| AI (vision, drafting, chatbot, **translation**) | **Google Gemini** (AI Studio) | No (free tier) | `.env` → `GEMINI_API_KEY` |
| Database / Auth | **Firebase** (Spark plan) | No | `CONFIG.FIREBASE` in `index.html` |
| Hosting / deploy | **Google Cloud Run** | Free trial credit | passed at deploy time |

- **Gemini key:** https://aistudio.google.com/app/apikey → paste into `.env`. Translation now goes through **Gemini** when a key is set (falls back to the free MyMemory API otherwise), so the whole-app translation is Google-powered too.
- **Firebase (optional cloud sync):** https://console.firebase.google.com → create project → add a Web app → copy the config into the `FIREBASE` block at the top of the JavaScript in `index.html`. Until then the app uses on-device storage.
- **Deploy to Cloud Run:**
  ```bash
  gcloud run deploy samadhan --source . --region asia-south1 \
    --allow-unauthenticated --set-env-vars GEMINI_API_KEY=your_key
  ```
  (A `Dockerfile` is included; Cloud Run can also build from source automatically.)

Runs **100% on the free tier** of Google's stack.

---


## What's new in this build

**Full-width, responsive layout.** The app no longer sits in a narrow centred strip — content now spreads to ~95% of the screen (up to 1320px). Feeds, the map list, profile lists, the community grid and the dashboard charts flow into responsive auto-fill card grids that add columns as the screen widens and collapse to a single column on phones (no overflow at any size). Forms (report & issue detail) stay capped to a comfortable reading column. The live rail reserves its own space so nothing overlaps.


**Community & volunteering (new in-app area).** A dedicated Community screen (reachable from Home, the welcome screen's Community tab, the About tab, or the in-app guide) with: local helper groups (RWAs, NGOs, volunteer collectives) you can **Join & volunteer** via a quick form (area, how you'll help, availability), and **community stories/blogs** members can **write and share in-app** — publish a story, like and share others'. The welcome screen also gained a **Community tab** with testimonials ("who's using Samadhan") and a one-tap "Open Community in the app".

**Live-updates toggle + layout fix.** The real-time rail now has an on/off switch (in the rail header and the guide), remembered across sessions. When it's on, wide-screen content makes room for it so the rail no longer overlaps screen controls; when it's off, content uses the full width. An always-visible **Live/Off pill** in the top bar lets you toggle it back on at any time (so disabling it is never a dead end). The welcome **Demo tab is now just the launch button**.


**Area-wise analytics dashboard (the Impact tab).** A filterable dashboard with **Area → Locality drill-down** (e.g. All Mumbai → Bandra → Linking Road). Pick an area and the locality dropdown repopulates; every chart recomputes live: KPI tiles (total / resolved % / active / avg-to-action), reports-by-category bars, a colour-coded status breakdown bar, an 8-week trend sparkline, and a tap-to-filter "top localities" list. Backed by a deterministic synthetic dataset across 6 Mumbai areas so the numbers are rich and stable.

**Live activity rail.** On wide screens a right-hand rail streams real-time-style updates — predicted pothole clusters, status changes, community verifications, crew dispatches and volunteer drives — refreshing every few seconds for a "live ops" feel.

**Community & volunteer framing.** The About tab now explains the social layer: local resident/RWA groups, volunteers who verify and run clean-up drives, NGOs/ward offices plugging in, and gamified leaderboards — so it reads as a community movement, not just a complaint box.

**Marathi hook + one-tap demo.** The welcome hero leads with a Marathi rhyme — *"खड्डा, कचरा, अंधार — समाधान करेल सुधार!"* (potholes, garbage, darkness — Samadhan brings the fix) — a prominent **Launch the live demo** button, and a one-line pointer to the in-app **?** guide.


**Welcome screen + in-app guide.** The app opens on a branded welcome screen with three tabs:
- **About this platform** — the problem, the 6-step workflow, a "who does what / who approves" role grid (Citizen → AI Agent → Community → Municipal department), and why it matters.
- **Tech stack** — every technology used and why it's free at hackathon scale.
- **Demo** — launches the live app.

Inside the app, a **?** button (top-right) opens a guide explaining each screen, the report→fix flow, and exactly who approves what (community approves authenticity; the municipal department approves resolution). The brand logo re-opens the welcome screen any time.

**Smarter navigation.** A proper history stack means the back button on any issue returns you to wherever you opened it from — the map, the home feed, or the exact Profile tab (Reported / Verified) you were on — instead of always dumping you on the map.


**Real street photos (free & license-safe).** Issues now show real Creative-Commons photos pulled by keyword from LoremFlickr (CC-licensed Flickr images). Google Images results are copyrighted, so they're not used; these are free to use. If a photo ever fails to load (offline/CSP), each image automatically falls back to a built-in illustration — so the app always looks complete. Toggle with `CONFIG.REAL_PHOTOS` (set `false` to use only the illustrations).

**My Activity portfolio.** The Profile tab now has a segmented control:
- **Reported** — every issue you've filed, with a category breakdown, each card tappable to its live status.
- **Verified** — every report you've verified, same drill-down.
- **Achievements** — badges + neighbourhood leaderboard.

**Whole-site translation into any language — free, no API key.** The globe button opens a searchable language picker (20+ languages incl. Hindi, Marathi, Tamil, Telugu, Bengali, Gujarati, Punjabi, Urdu, Arabic, Spanish, French, Chinese, Japanese…). Choosing one translates the **entire live interface — including dynamic issue text — not just fixed labels**. How it stays free:
- The app renders in English (source) and translates the live DOM via **MyMemory** (no signup, no key, CORS-enabled, callable straight from the browser).
- **Every unique string is translated once and cached on-device forever** (`localStorage`), so the whole UI costs ~1–2k characters one time, then makes zero further calls — comfortably inside MyMemory's free 5,000-chars/day anonymous tier.
- Hindi & Marathi ship with a hand-written dictionary that's pre-seeded into the cache, so they're instant and work fully offline; any other language flows through the free API and is cached after first use.
- If the API ever fails or you hit the daily cap, strings simply stay in English — nothing breaks.
- Optional: set `CONFIG.TRANSLATE_EMAIL` to any email to raise the free limit to 50,000 chars/day (still no signup).

**Spoken in any language.** Text-to-speech ("Listen" buttons + per-chat-message speaker) reads content aloud in the selected language via the browser's Speech Synthesis. Voice input (speech-to-text) powers the chatbot mic and the voice-report flow.

**Report by voice + tappable demo.** "Report by voice instead" opens a sheet with a live mic (speech-to-text) *and* a tappable **"Play a sample voice report"** — it speaks a realistic spoken complaint aloud and auto-fills the transcript, then runs the same AI analyse → file → track flow. (No external audio file to break; it uses the device's own voice so it works offline and in any language.)


## ✨ What's inside

| Area | Feature |
|---|---|
| **Reporting** | Photo/upload + voice option, guided 4-step flow |
| **Try-it samples** | Built-in tappable sample photos in the report flow — no photo on your device needed to demo the full AI flow |
| **AI agent** | Gemini reads the photo → category + severity + draft complaint → routes to department → files → monitors SLA (visible **agent activity log**) |
| **Map** | Live interactive map (Leaflet + OpenStreetMap) — **no API key, no billing account** — status-coloured markers, popups, draggable location pin |
| **Verification** | Community confirms issues; higher verification = higher priority |
| **Tracking** | Live timeline: Reported → Filed → In progress → Resolved + audit trail |
| **Impact** | Resolution stats, category/weekly charts, **predictive hotspot insights** |
| **Gamification** | Points, badges, levels (Citizen → Guardian → Community Hero → Civic Champion), area leaderboard |
| **Guide** | "Saathi" Gemini chatbot + first-run onboarding |
| **i18n** | Gemini replies in English / Hindi / Marathi (live mode) |

---

## 🚀 Run it now (demo mode, zero setup)

The app works fully without any keys — seeded with sample Mumbai data.

```bash
# Option A: just open it
open index.html          # (or double-click)

# Option B: run the server (enables the secure Gemini proxy too)
npm install
npm start                # → http://localhost:8080
```

Without keys you'll see a **"Demo mode"** banner; the AI uses smart mock responses so every screen is explorable.

> **Demoing the report flow?** On the report screen, tap one of the **sample photos** (Pothole / Garbage / Streetlight) — it behaves exactly like you uploaded that photo and runs the full analyse → file → track flow. The same images also live in `assets/samples/` (PNG) if you'd rather upload one from disk. With a Gemini key set, the samples are analysed for real by Gemini.

---

## 🔑 Going live — add your keys

There are **three** integrations. Each is free for hackathon-scale use.

### 1. Gemini (the AI brain) — *server-side, secure*
1. Go to **[aistudio.google.com](https://aistudio.google.com)** → **Get API key** → create key (no credit card).
2. Copy `.env.example` to `.env` and paste it:
   ```
   GEMINI_API_KEY=AIza...your_key
   ```
3. Restart `npm start`. The console will print `Gemini key: set`.
   > The key lives only in `.env` / Cloud Run — it is **never** sent to the browser.

### 2. Map — *nothing to do* ✅
The map uses **Leaflet + OpenStreetMap**: a fully interactive map (pan, zoom, markers, popups, draggable pin, GPS) that needs **no API key and no credit card**. It works out of the box, in demo mode and in production.
   > Want different map tiles? Change `CONFIG.TILE_URL` in `index.html` to any free provider (e.g. CARTO, Stadia). Area names on the report screen come from OpenStreetMap's free Nominatim reverse-geocoder.

### 3. Firebase (sign-in + cloud database) — *client-side, optional*
1. **[console.firebase.google.com](https://console.firebase.google.com)** → create/select project.
2. **Build → Authentication** → enable **Google** sign-in.
3. **Build → Firestore Database** → create (test mode is fine for the demo).
4. **Project settings → Your apps → Web app** → copy the config object.
5. Paste each value into `index.html` → `CONFIG.FIREBASE`.
   > Without this, the app stores data locally in the browser — perfectly fine for judging a demo.

The map is live from the start. Adding Gemini + Firebase keys removes the "Demo mode" banner and switches AI + storage from mock/local to real.

---

## ☁️ Deploy to Google Cloud (required by the hackathon)

### Easiest — Google AI Studio → Cloud Run (one click)
1. Open **[aistudio.google.com](https://aistudio.google.com)** → **Build**.
2. Import this project (or paste the files), then click **Deploy → Cloud Run**.
3. AI Studio injects your `GEMINI_API_KEY` server-side automatically and gives you a public `run.app` URL.

### Manual — gcloud CLI
```bash
gcloud run deploy samadhan \
  --source . \
  --region asia-south1 \
  --allow-unauthenticated \
  --set-env-vars GEMINI_API_KEY=YOUR_KEY
```
Cloud Run builds the container from `package.json`, runs `npm start`, and returns a live HTTPS URL. Free tier: 2M requests/month, scales to zero.

> Put the returned `run.app` URL into your BlockseBlock submission as the **Deployed Application Link**.

---

## 🧱 Architecture

```
Browser (index.html, single-file SPA)
   │  photo / chat
   ▼
/api/gemini  ──►  server.js (Express on Cloud Run)  ──►  Gemini 2.5 Flash
   │                                                       (key stays here)
   ├──►  Leaflet + OpenStreetMap  (markers, popups, location pin · no key)
   └──►  Firebase Auth + Firestore  (sign-in, issues)   ← optional; localStorage fallback
```

**Graceful degradation:** Firestore → localStorage → in-memory, and Gemini → smart mock. The app never breaks, with or without keys.

## 🗂️ Files
- `index.html` — the entire front-end app (UI, flows, gamification, chatbot)
- `server.js` — static host + secure Gemini proxy
- `package.json`, `.env.example` — server config
- `CONFIG` block at the top of `index.html` — Firebase config + map tile URL

## 🏆 Maps to the evaluation rubric
- **Agentic depth** — the autonomous file → route → monitor → escalate loop, shown live in the agent log
- **Problem solving & impact** — full lifecycle, not just reporting; resolution + predictive prevention
- **Innovation** — predictive hotspots, auto-escalation, before/after verification, civic-karma economy
- **Google tech** — AI Studio, Cloud Run, Gemini, Firebase (map is OpenStreetMap to stay card-free)
- **Product & design** — guided flow, multilingual chatbot, minimal accessible UI, gamification
